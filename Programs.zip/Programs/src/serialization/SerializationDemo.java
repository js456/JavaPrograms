/**
 * 
 */
package serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * @author jsaini
 *
 */
public class SerializationDemo {
	public static void serialize()
	{
		Helper helper = new Helper("HelperTest",45);
		try {
			FileOutputStream out = new FileOutputStream("output.ser");
			ObjectOutputStream objOut=new ObjectOutputStream(out);
			objOut.writeObject(helper);
			objOut.close();
			out.close();
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void deSerialize() throws ClassNotFoundException
	{
		try {
			FileInputStream inp = new FileInputStream("output.ser");
			ObjectInputStream objInp=new ObjectInputStream(inp);
			Helper helper = (Helper)objInp.readObject();
			objInp.close();
			inp.close();
			System.out.println("After object reading values is : "+helper.getName());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		serialize();
		try {
			deSerialize();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
class Helper implements Serializable{
	private String name;
	private int id;
	Helper(String name,int id){
		this.name= name;
		this.id= id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}