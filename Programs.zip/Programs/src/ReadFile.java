import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class ReadFile { 
	public static boolean toDelete(String intent,BufferedWriter deleted) throws IOException
	{
		BufferedReader brDelete = new BufferedReader(new FileReader(new File("toDeleteAgain.txt")));
		String delete;
		while((delete = brDelete.readLine())!=null)
		{
			if(intent.trim().equalsIgnoreCase(delete.trim()))
			{
				deleted.write(delete);
				deleted.write("\n");
				return true;
			}
		}
		brDelete.close();
		return false;
	}
	public static void format() throws IOException
	{

		BufferedReader br = new BufferedReader(new FileReader(new File("AllIntents.txt")));
		
		BufferedWriter bw = new BufferedWriter(new FileWriter(new File("vfOutputFormatedAgain.txt")));
		BufferedWriter deleted = new BufferedWriter(new FileWriter(new File("vfOutputFormatedDeleted.txt")));
		String line;
		
		while((line = br.readLine())!=null)
		{
			String intent = line.split("\t")[1];
			if(!toDelete(intent, deleted))
			{
				line = line.trim();
				bw.write(line);
				bw.write("\n");
			}
			
		}
		deleted.flush();
		deleted.close();
		bw.flush();
		bw.close();
		br.close();
		Object obj;
		System.out.println("done");
		
	
	}
	public static void main(String[] args) throws IOException {
		//format();
		/*try {
			BufferedWriter deleted = new BufferedWriter(new FileWriter(new File("deleted.txt")));
			BufferedReader br = new BufferedReader(new FileReader(new File("vfIntents.txt")));
			
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File("vfOutput.txt")));
			String line;
			
			while((line = br.readLine())!=null)
			{
				String intent = line.split("\t")[1];
				if(!toDelete(intent,deleted))
				{
					bw.write(line);
					bw.write("\n");
				}
			}
			deleted.flush();
			deleted.close();
			bw.flush();
			bw.close();
			br.close();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		/*replaceEpicWithIntent("epicIntentMapping.txt", "changedClassifier.txt");*/
		testGivenWithPredictedIntent("massPredictComparision.txt");
		System.out.println("done");
	}
	public static void replaceEpicWithIntent(String epicIntentFile, String fileToMap)
	{
		BufferedWriter bw=null;
		Map<String,String> epicIntentMap = new HashMap<String,String>(); 
		getEpicIntentMap(epicIntentFile, epicIntentMap);
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(fileToMap)));
			bw = new BufferedWriter(new FileWriter(new File("mappedFile.txt")));
			String line;
				while((line = br.readLine())!=null)
				{
					String lineArr[]= line.split("\t");
					System.out.println(lineArr[2].toLowerCase());
					System.out.println(epicIntentMap.get(lineArr[2].toLowerCase()));
					String intent= epicIntentMap.get(lineArr[2].toLowerCase().trim());
					if(intent == null)
					{
						intent=lineArr[2].toLowerCase().trim();
					}
					bw.write(lineArr[0]+"\t"+lineArr[1]+"\t"+intent);
					if(lineArr.length>5)
					bw.write("\t"+lineArr[3]+"\t"+lineArr[4]+"\t"+lineArr[5]);
					bw.write("\n");
				}
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(bw!= null)
			{
				try {
					bw.flush();
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		
	}
	public static void testGivenWithPredictedIntent(String givenWithPredictFile)
	{
		BufferedWriter bw=null;
		BufferedWriter unMatched = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(givenWithPredictFile)));
			bw = new BufferedWriter(new FileWriter(new File("matched.txt")));
			unMatched = new BufferedWriter(new FileWriter(new File("unMatched.txt")));
			/*bw = new BufferedWriter(new FileWriter(new File("notPredicted.txt")));*/
			String line;
				while((line = br.readLine())!=null)
				{
					String lineArr[]= line.split("\t");
					if(lineArr.length>2)
					{
						if(lineArr[1].toLowerCase().trim().equals(lineArr[2].toLowerCase().trim()) )
						{
						
							bw.write(line);
							bw.write("\n");
						}
						else
						{
							unMatched.write(line);
							unMatched.write("\n");
						}
					}
					
				}
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(bw!= null)
			{
				try {
					bw.flush();
					bw.close();
					unMatched.flush();
					unMatched.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		
	}
	public static void getEpicIntentMap(String epicIntentFile, Map<String,String> epicIntentMap)
	{
		BufferedReader br=null;
		try {
			 br= new BufferedReader(new FileReader(new File(epicIntentFile)));
			String line;
				while((line = br.readLine())!=null)
				{
					String lineArr[]= line.split("\t");
					epicIntentMap.put(lineArr[1].toLowerCase().trim(), lineArr[0]);
				}
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(br!=null)
			{
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
	}
}
