/**
 * 
 */
package objectClassesConcept;

/**
 * @author jsaini
 *
 */
public class Override {

	public static void main(String[] args) {
		//Animal animal = new Horse();
		Horse horse = new Horse("Jitendra");
		System.out.println();
		final int a;
		a=56;
		
		horse.doSomething(1.2);
		//horse.eat(new String());
	}
}

class Animal{
	public Animal(String name) {};
	public void eat() {System.out.println("Ok, Let's eat something");};
}
class Horse extends Animal{
	/**
	 * @param name
	 */
	public Horse(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	public void doSomething(String str)
	{
		System.out.println("do something String");
	}
	public void doSomething(Double str)
	{
		System.out.println("do something Double");
	}
	public void doSomething(Object str)
	{
		System.out.println("do something Object");
	}
	public void doSomething() {
		System.out.println("do something");
	}
	public void eat(String name) {
		System.out.println("see that's how a horse eat");
	}
	public void eat(Object name) {System.out.println("I am calling from object");};
}