import java.util.Scanner;

/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class Substrings {

	public static void main(String[] args) {
		
		String string, sub;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a string to print it's all substrings");
		string = in.nextLine();
		int length = string.length();
		System.out.println("Substring are: ");
		for(int i=0; i<string.length();i++) {
			for(int j= i+1; j<=string.length();j++)
				System.out.println(string.substring(i,j));
		}
	}
}



