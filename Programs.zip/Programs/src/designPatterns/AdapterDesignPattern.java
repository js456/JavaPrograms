/**
 * 
 */
package designPatterns;

/**
 * @author jsaini
 *
 */
public class AdapterDesignPattern {
	public static Volts getVolt(SocketAdapter adapter,int voltInput)
	{
		switch(voltInput) {
		case 3:
			return adapter.get3Volts();
		case 12:
			return adapter.get12olts();
		case 240:
			return adapter.get240Volts();
		default:
			System.out.println("Ohhh, Sorry I can't provide desired volts. ");
			return null;
		}
	}
	public static void main(String[] args) {
		SocketAdapter  adapter = new AdapterImpl();
		Volts volt3 = getVolt(adapter, 3);
		Volts volt12 = getVolt(adapter, 12);
		System.out.println(" V3 volts using class adapter : "+volt3.getVolt());
	}
	
}
class Volts{
	int volt;
/**
 * 
 */
public Volts(int volt) {
	this.volt=volt;
	// TODO Auto-generated constructor stub
}
	public int getVolt() {
		return volt;
	}

	public void setVolt(int volt) {
		this.volt = volt;
	}
	
}
class Socket{
	public Volts getVolts()
	{
		return new Volts(240);
	}
}
interface SocketAdapter{
	public Volts get3Volts();
	public Volts get12olts();
	public Volts get240Volts();
	
}
class AdapterImpl extends Socket implements SocketAdapter {

	/* (non-Javadoc)
	 * @see designPatterns.AdapterInterface#get3Volts()
	 */
	@Override
	public Volts get3Volts() {
		Volts volts= getVolts();
		return convert(volts,80);
	}

	/* (non-Javadoc)
	 * @see designPatterns.AdapterInterface#get12olts()
	 */
	@Override
	public Volts get12olts() {
		// TODO Auto-generated method stub
		Volts volts= getVolts();
		return convert(volts,12);
	}

	/* (non-Javadoc)
	 * @see designPatterns.AdapterInterface#get240Volts()
	 */
	@Override
	public Volts get240Volts() {
		// TODO Auto-generated method stub
		return getVolts();
	}
	public Volts convert(Volts volt, int number)
	{
		return new Volts(volt.volt/number);
	}
	
}

class AdapterOjbectImpl implements SocketAdapter {

	/* (non-Javadoc)
	 * @see designPatterns.AdapterInterface#get3Volts()
	 */
	Socket socket = new Socket();
	@Override
	public Volts get3Volts() {
		Volts volts= socket.getVolts();
		return convert(volts,80);
	}

	/* (non-Javadoc)
	 * @see designPatterns.AdapterInterface#get12olts()
	 */
	@Override
	public Volts get12olts() {
		// TODO Auto-generated method stub
		Volts volts= socket.getVolts();
		return convert(volts,12);
	}

	/* (non-Javadoc)
	 * @see designPatterns.AdapterInterface#get240Volts()
	 */
	@Override
	public Volts get240Volts() {
		// TODO Auto-generated method stub
		return socket.getVolts();
	}
	public Volts convert(Volts volt, int number)
	{
		return new Volts(volt.volt/number);
	}
	
}
