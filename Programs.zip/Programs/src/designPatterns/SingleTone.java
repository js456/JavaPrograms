/**
 * 
 */
package designPatterns;

/**
 * @author jsaini
 *
 */
public final class SingleTone implements Cloneable {
	private static SingleTone obj;
	private  SingleTone() {};
	public static SingleTone getInstance()
	{
		if(obj == null)
		{
			synchronized (SingleTone.class) {
				if(obj == null)
					obj = new SingleTone();
				
			}
		}
		return obj;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		throw new CloneNotSupportedException("Singleton cannot be clonned");
	}

	public static void main(String[] args) {
		SingleTone obj = SingleTone.getInstance();
		SingleTone obj2 = SingleTone.getInstance();
		System.out.println(obj.hashCode());
		System.out.println(obj2.hashCode());
		try {
			SingleTone temp = (SingleTone) obj.clone();
			System.out.println(temp.hashCode());
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
class SingleToneEarly{
	private static SingleToneEarly object= new SingleToneEarly();
	private SingleToneEarly() {}
	public static SingleToneEarly getInstance() {
		return object;
	}
}
