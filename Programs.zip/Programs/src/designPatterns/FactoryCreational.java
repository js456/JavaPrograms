/**
 * 
 */
package designPatterns;

/**
 * @author jsaini
 *
 */
public class FactoryCreational implements Cloneable {

	public static void main(String[] args) {
		System.out.println(ComputerFactory.getComputer("Laptop", "16 GB").getClass());
	}
}

abstract class Computer{

	public abstract String getRAM();
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "RAM IS :"+this.getRAM();
	}
}
class PC extends Computer{

	String ram;
	/* (non-Javadoc)
	 * @see designPatterns.Computer#getRAM()
	 */
	PC(String ram){
		this.ram=ram;
	}
	@Override
	public String getRAM() {
		// TODO Auto-generated method stub
		return null;
	}
}
class Laptop extends Computer{

	String ram;
	Laptop(String ram){
		this.ram=ram;
	}
	/* (non-Javadoc)
	 * @see designPatterns.Computer#getRAM()
	 */
	@Override
	public String getRAM() {
		// TODO Auto-generated method stub
		return null;
	}
}
class ComputerFactory{
	public static Computer getComputer(String type, String ram)
	{
		if(type.equalsIgnoreCase("PC")) return new PC(ram);
		else if(type.equalsIgnoreCase("laptop")) return new Laptop(ram);
		return null;
	}
}