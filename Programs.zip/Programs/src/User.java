/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class User {

	
	public boolean isMatch(String name)
	{
		if(name.equals("john"))
			return true;
		return false;
	}
	public static void main(String []args)
	{
		System.out.print("sdf");
	}
}
