/**
 * 
 */
package searchingSorting;

/**
 * @author jsaini
 *
 */
public class MergeSort {
	
	public static void printArray(int arr[])
	{
		for(int number : arr)
		{
			System.out.print(number);
		}
	}
	public static void mergeSort(int arr[], int min , int max) {
		if(min<max) {
			int mid = (min+max)/2;
			mergeSort(arr, min, mid);
			mergeSort(arr, mid+1,max);
		}
		
	}
	
	public int[] merge(int []first,int []second, int []output) {
		return output;
	}
	
	public static void main(String[] args) {
		int arr[]= {10,50,63,20,78,15,25,35};
		mergeSort(arr,0,arr.length-1);
	}

}
