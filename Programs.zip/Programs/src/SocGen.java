import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeSet;

/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class SocGen {
	

	static String convertToBinaryUsingString(int no){
	    String result = new String();
	    int i =0;
	    while (no > 0){
	        result+=no%2;
	        i++;
	        no = no/2;
	    }
	    return new StringBuilder(result).reverse().toString();
	}
	public static int getCountOnes(int number)
	{
		if(number ==0)
			return 0;
		int count=0;
		while(number>0)
		{
			if(number%10==1)
				count++;
			number=number/10;
		}
		return count;
	}
	public static void printSet(int arr[])
	{
		HashMap<Integer,TreeSet>numCountMap=new HashMap<Integer,TreeSet>();
		String binaryArr[]= new String[arr.length];
		for(int i=0;i<arr.length;i++)
		{
			binaryArr[i]= convertToBinaryUsingString(arr[i]);
			int countOne=getCountOnes(Integer.parseInt(binaryArr[i]));
			if(numCountMap.get(countOne)!=null) {
				TreeSet <Integer>set=new TreeSet<Integer>();
				set=numCountMap.get(countOne);
				set.add(arr[i]);
				numCountMap.put(countOne,set);
			}
			else {
				TreeSet <Integer>set=new TreeSet<Integer>();
				set.add(arr[i]);
				numCountMap.put(countOne, set);
			}
			
			
		}
		for(Map.Entry<Integer, TreeSet> entry: numCountMap.entrySet())
		{
			System.out.print(""+entry.getValue().stream().toArray(Integer[] ::new)[0]+" ");
		}
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int count=sc.nextInt();
		for(int i=0;i<count;i++)
		{
			int arrSize=sc.nextInt();
			int tempArr[]=new int[arrSize];
			for(int j=0;j<arrSize;j++)
			{
				tempArr[j]=sc.nextInt();
			}
			printSet(tempArr);
		}
	}
}
