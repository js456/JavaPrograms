import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class WordsToNumber
{
  public static void main(String[] args)
  {
    List<String> words = Arrays.asList( "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", 
      "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN", "TWENTY", 
      "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY", "HUNDRED", 
      "THOUSAND", "MILLION", "BILLION", "TILLION", "QUADRILLION", "QUINTILLION", "SIXTILLION", "SEPTILLION", 
      "OCTILLION", "NONILLION", "DECILLION" );
    
    List<String> numbers = Arrays.asList( "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", 
      "19", "20", "30", "40", "50", "60", "70", "80", "90", "100", "1000", "1000000", "1000000000", "1000000000000", 
      "1000000000000000", "1000000000000000000", "1000000000000000000000", "1000000000000000000000000", 
      "1000000000000000000000000000", "1000000000000000000000000000000", "1000000000000000000000000000000000" );
    


    String inp = "fourty five";
    inp = inp.replace(',', ' ');
    inp = inp.replace('-', ' ');
    inp = inp.toUpperCase();
    System.out.println(inp);
    String[] splitWords = inp.split(" ");
    int len = splitWords.length;
    BigDecimal num = new BigDecimal("0");
    BigDecimal temp = new BigDecimal("0");
    Boolean flag = false;
    Boolean counter = false;
    try
    {
      for (int i = 0; i < len; i++)
      {
        flag = false;
        counter = false;
        if (!splitWords[i].isEmpty())
        {
          int index = words.indexOf(splitWords[i]);
          if (index > 28)
          {
            temp = temp.multiply(new BigDecimal(numbers.get(index)));
            flag = true;
          }
          else if (index == 28)
          {
            temp = temp.multiply(new BigDecimal(numbers.get(index)));
          }
          else
          {
            temp = temp.add(new BigDecimal(numbers.get(index)));
            counter = true;
          }
          if (flag)
          {
            num = num.add(temp);
            temp = new BigDecimal("0");
          }
        }
      }
      if (counter) {
        num = num.add(temp);
      }
      System.out.println(num);
    }
    catch (Exception e)
    {
      System.out.println("Wrong Input");
    }
  }
}
