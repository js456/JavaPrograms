/**
 * 
 */
package datastructures;

/**
 * @author jsaini
 *
 */
public class StackUsingArray {
	 

}

class Stack{
	int size;
	int arr[];
	int pointer;
	Stack(int size)
	{
		this.size=size;
		this.arr=new int[size];
	}
	public void pop()
	{
		arr[pointer]=0;
		pointer--;
	}
	public void push(int element) {
		if(pointer < size) {
			arr[++pointer]=element;
			pointer++;
		}
		
	}
}