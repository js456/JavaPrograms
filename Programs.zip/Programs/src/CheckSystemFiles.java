
public class CheckSystemFiles {


	public static void main(String []args){
		
		
	}
}
