import java.util.ArrayList;

/**
 * 
 */

/**
 * @author jsaini
 *
 */
interface TestInterface {
	
	static String producer() {
		return "Jitendra Saini";
	}
	default String getOverview()
	{
		return "It is just an overview";
	}

}
public class ProducerInterface{
	
	public static boolean isPresent(String name)
	{
		if(name.equals("jeet"))
			return true;
		return false;
	}
	public static void main(String[] args) {
		System.out.println(TestInterface.producer());
		System.out.println();
		
		ArrayList<String>list=new ArrayList<String>();
		list.add("jeet");
		list.add("john");
		boolean isPresent= list.stream().anyMatch(ProducerInterface::isPresent);
		System.out.println(isPresent);
		
		User user = new User();
		boolean isMatch=list.stream().anyMatch(user::isMatch);
		System.out.println(isMatch);
		
	}
}