import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class ReadExcelWithoutPOI {

	public static void main(String[] args) {
		
		BufferedReader reader=null;
		try{
			reader=new BufferedReader(new FileReader(new File("SampleCSVFile_11kb.csv")));
			String line="";
			while((line=reader.readLine())!=null)
			{
				for(String str:line.split("\\t"))
				{
					System.out.println(str);
				}
				//System.out.println(line);
			}
		}
		catch(IOException e)
		{
			System.out.println(e.toString());
		}
		
	}
}
