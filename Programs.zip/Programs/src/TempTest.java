import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;

/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class TempTest {
	public static void main(String[] args) {
		
		HashMap<Employee,Integer>map=new HashMap<Employee, Integer>();
		Hashtable table;
		LinkedHashMap maplinked;
		HashSet<Integer>set;
		Employee emp=new Employee("Jitendra",2000000);
		map.put(emp, 2);
		emp.name="Saini";
		System.out.println(emp.hashCode());
		System.out.println(map);
		
		ArrayList<String>list1=new ArrayList<>();
		list1.add("foo");
		ArrayList<String>list2=list1;
		ArrayList<String>list3=new ArrayList<>(list2);
		list1.clear();
		list2.add("bar");
		list3.add("baz");
		System.out.println(list1);
		System.out.println(list2);
		System.out.println(list3);}

}

interface FirstInterface{
	String getName();
	default String getDept()
	{
		return "FirstInterface department";
	}
	default String getRole()
	{
		return "FirstInterface Roles";
	}
}
interface SecondInterface{
	String getName();
	default String getDept()
	{
		return "FirstInterface department";
	}
	default String getDesg()
	{
		return "FirstInterface Designation";
	}
}

class Employee implements FirstInterface,SecondInterface{
	public String name;
	public double salary;
	/**
	 * 
	 */
	public Employee(String name,double salary) {
		this.name=name;
		this.salary=salary;
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see FirstInterface#getName()
	 */
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	/* (non-Javadoc)
	 * @see FirstInterface#getDept()
	 */
	/* (non-Javadoc)
	 * @see FirstInterface#getDept()
	 */
	@Override
	public String getDept() {
		// TODO Auto-generated method stub
		return FirstInterface.super.getDept();
	}
}
