
	
	import java.util.ArrayList;
import java.util.Scanner;

	public class StringMatch 
	{
	    static int temp,i=0,j=0; static boolean flag=true,matcher=false;

	    static String str=null,mstr=null;static char astr[],amstr[];

	    static void getter(){
	        Scanner sc = new Scanner(System.in);
	        str = sc.nextLine();
	        //String str="today is Monday"; 
	        astr=str.toCharArray();
	         mstr = sc.nextLine();
	        //String mstr="is"; 
	         amstr=mstr.toCharArray();
	    }

	    static void stringMatch(){
	        while(i<astr.length){
	            if(astr[i]==amstr[j]){
	            while((j!=amstr.length)&&flag){temp=i;
	                if(astr[i]!=amstr[j]) {flag=false;matcher=false;}
	                else{matcher=true;}
	                i++;j++;
	                //System.out.println(i+"\t"+j);
	            }if(matcher==true)break;i=temp;}i++;j=0;flag=true;

	        }
	        if(matcher==true) {System.out.println("true");}
	        else    {System.out.println("false");}
	    }

	    public static void main(String[] args) {

	    ArrayList<String>list=new ArrayList<String>();
	    list.contains("");
/*	    StringMatch.getter();
	    StringMatch.stringMatch();*/
	    }
}