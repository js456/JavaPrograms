/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class TestJavaInheritance {

	public static void main(String[] args) {
		TestA a = new TestB();
		TestB b = new TestB();
		System.out.println(a.x);
		a.printIt();
		System.out.println(b.x);
		b.printIt();
	}
}
class TestA {
	int x=200;
	public void printIt()
	{
		System.out.println(x);
	}
}
class TestB extends TestA {
	int x=300;
	public void printIt()
	{
		System.out.println(x);
	}
}