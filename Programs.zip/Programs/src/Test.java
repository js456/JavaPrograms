import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class Test {

	public static StringBuffer updateString(StringBuffer sb)
	{
		
		Set<String>set=new LinkedHashSet<String>();
		set.add("John");
		set.add("Abhi");
		set.add("J");
		set.add("bhi");
		set.add("i");
		System.out.println(set);
		
		//sb.append("updating in method update String");
		return sb;
	}
	
	public static void main(String[] args) {
	/*	StringBuffer sb =new StringBuffer("Intial value in string buffer");
		System.out.println(updateString(sb));*/
		LinkedHashMap <String,String>map=new LinkedHashMap<String, String>();
		map.put("key", "value");
		LinkedHashMap <String,String>map2=map;
		System.out.println(map2.toString());
		map2.put("key2", "value2");
		System.out.println(map2.toString());
		System.out.println(map.toString());
		
	}

	public int x;
}
