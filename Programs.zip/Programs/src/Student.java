import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class Student implements Comparable {
	
	String name;
	int rollNumber;
	/**
	 * 
	 */
	public Student(String name,int rollNumber) {
		this.name=name;
		this.rollNumber=rollNumber;
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
/*	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		Student st=(Student)o;
		if(st.rollNumber <)
		return 0;
	}*/
	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	/*@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Student st1=(Student)o1;
		Student st2=(Student)o2;
		if(st1.rollNumber < st2.rollNumber)
			return 1;
		if(st1.rollNumber > st2.rollNumber)
			return -1;
		if(st1.rollNumber == st2.rollNumber)
			return 0;
		return 0;
	}*/
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Object o) {
		
		int rollNumber=((Student)o).rollNumber;
		return rollNumber-this.rollNumber;
		// TODO Auto-generated method stub
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	
	
 public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
public static void main(String[] args) {
	List<Student>stList=new ArrayList<Student>();
	Student st1=new Student("Jitnedra",4);
	Student st2=new Student("Jit",6);
	Student st3=new Student("Jidra",8);
	Student st4=new Student("Jitne",2);
	stList.add(st1);
	stList.add(st2);
	stList.add(st3);
	stList.add(st4);
	Collections.sort(stList);
	for(Student obj:stList) {
		System.out.println(obj.rollNumber);
	}
	
}
}
