/**
 * 
 */
package garbageCollection;

/**
 * @author jsaini
 *
 */
public class TestGrabage {

	String name;
	/**
	 * 
	 */
	public TestGrabage(String name) {
		this.name=name;
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		TestGrabage obj1= new TestGrabage("Jitendra");
		TestGrabage obj2= new TestGrabage("John");
		obj1=obj2;
		obj2=null;
		
		//obj1=null;
		System.gc();
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#finalize()
	 */
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		System.out.println(this.name+" garbage collected");
		super.finalize();
	}
}
