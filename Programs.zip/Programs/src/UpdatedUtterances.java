import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class UpdatedUtterances { 
	
	protected void name() {
		
	}
	public static boolean toDelete(String intent,BufferedWriter deleted) throws IOException
	{
		BufferedReader brDelete = new BufferedReader(new FileReader(new File("toDeleteAgain.txt")));
		String delete;
		while((delete = brDelete.readLine())!=null)
		{
			if(intent.trim().equalsIgnoreCase(delete.trim()))
			{
				deleted.write(delete);
				deleted.write("\n");
				return true;
			}
		}
		brDelete.close();
		return false;
	}
	public static void format() throws IOException
	{

		
		BufferedReader brOriginal = new BufferedReader(new FileReader(new File("original.txt")));
		
		/*BufferedWriter bw = new BufferedWriter(new FileWriter(new File("output.txt")));*/
		BufferedWriter finalUpdated = new BufferedWriter(new FileWriter(new File("finalUpdated.txt")));
		String originalLine;
		int counter=0;
		while((originalLine = brOriginal.readLine())!=null)
		{
			String originalIntent = originalLine.split("\t")[0];
			BufferedReader brUpdated = new BufferedReader(new FileReader(new File("updated.txt")));
			String lineUpdated;
			boolean flag = true;
			while((lineUpdated = brUpdated.readLine())!=null)
			{
				String updatedlIntent = lineUpdated.split("\t")[0];
				if(updatedlIntent.equalsIgnoreCase(originalIntent))
				{
					flag=false;
					counter++;
					if(originalLine!=lineUpdated)
					{
						//System.out.println("updated-----> "+counter);
						System.out.println("original-----> "+originalLine);
						System.out.println("updated-----> "+lineUpdated);
						finalUpdated.write(lineUpdated);
					}
					else
					{
						finalUpdated.write(originalLine);
					}
					finalUpdated.write("\n");
					break;
					/*else {
						System.out.println("updated-----> "+line);
						System.out.println("original-----> "+lineOriginal);
					}*/
				}
				
			}	
			if(flag)
			{
				finalUpdated.write(originalLine);
				finalUpdated.write("\n");
			}
			brUpdated.close();
		}
		finalUpdated.flush();
		finalUpdated.close();
		brOriginal.close();
		System.out.println("done");
		
	
	}
	
	
	public static void main(String[] args) throws IOException {
		
		
	try {badError();
	System.out.println("a");
	}
	catch(Exception e){System.out.println("b");}
	finally {System.out.println("c");}
	System.out.println("d");
		/*format();*/
		/*try {
			BufferedWriter deleted = new BufferedWriter(new FileWriter(new File("deleted.txt")));
			BufferedReader br = new BufferedReader(new FileReader(new File("vfIntents.txt")));
			
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File("vfOutput.txt")));
			String line;
			
			while((line = br.readLine())!=null)
			{
				String intent = line.split("\t")[1];
				if(!toDelete(intent,deleted))
				{
					bw.write(line);
					bw.write("\n");
				}
			}
			deleted.flush();
			deleted.close();
			bw.flush();
			bw.close();
			br.close();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	/**
	 * 
	 */
	private static void badError() {
		// TODO Auto-generated method stub
		throw new Error();
	}
	/**
	 * @param a
	 */
	private static long[] fix(long[] a) {
		// TODO Auto-generated method stub
		a[1]=12;
		return a;
	}
}

class A{
	private int e;
	
	/**
	 * 
	 */
	private void obj() {
		// TODO Auto-generated method stub
		UpdatedUtterances obj = new UpdatedUtterances();
		obj.name();
	}
}