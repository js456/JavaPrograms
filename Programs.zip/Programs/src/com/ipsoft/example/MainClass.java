/**
 * 
 */
package com.ipsoft.example;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Phaser;

/**
 * @author jsaini
 *
 */
public class MainClass {

	/**
	 * @throws ExecutionException 
	 * @throws InterruptedException 
	 * 
	 */
	private Phaser phaser = new Phaser(1);
public static void main(String[] args) throws InterruptedException, ExecutionException {
	
	Student s1 = new Student();
	//Thread t1 = new Thread(s1);
	//t1.start();
	ExecutorService service =  Executors.newSingleThreadExecutor();
	Callable<String> callable = new Student();
	Future<String> future = service.submit(callable);
	System.out.println(future.get());

	ExecutorService service1 =  Executors.newSingleThreadExecutor();
	Callable<String> callable1 = new Student();
	Future<String> future1 = service.submit(callable1);
	System.out.println(future1.get());
	//t1.isDaemon();
}
}
