/**
 * 
 */
package com.ipsoft.example;

import java.util.concurrent.Callable;
import java.util.concurrent.Phaser;

/**
 * @author jsaini
 *
 */
public class Student implements Callable<String>{
	private Phaser phaser;
	
	
	/**
	 * @param phaser
	 */
	public Student(Phaser phaser) {
		super();
		this.phaser = phaser;
		this.phaser.register();
	}

	/**
	 * 
	 */
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	void getNumber()
	{
		System.out.println("get Number");
	}

	/* (non-Javadoc)
	 * @see java.util.concurrent.Callable#call()
	 */
	@Override
	public String call() throws Exception {
		getNumber();
		this.phaser.arriveAndDeregister();
		return "Callable";
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	/*@Override
	public void run() {
		// TODO Auto-generated method stub
		getNumber();
		
	}*/
}
