/**
 * 
 */
package geeksforgeeks;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * @author jsaini
 *
 */
public class Subsequence {
	
	static char []arr;
	static String[] output=new String[100];
	static int counter_temp=0;
	static HashSet<String> st = new HashSet<>();
	
	static void subsequence(String str)
	{
		
		for(int i=0;i<str.length();i++)
		{
			for(int j=str.length();j>i;j--)
			{
				String sub_str=str.substring(i, j);
				if(!st.contains(sub_str))
					st.add(sub_str);
				for(int k=0; k<sub_str.length()-1;k++ )
				{
					StringBuffer sb= new StringBuffer(sub_str);
					sb.deleteCharAt(k);
					if(!st.contains(sb))
						;
					subsequence(sb.toString());
					
				}
			}
		}
	}
	static void getSequence(String str)
	{
		//output=new int[str.length()];
		arr=str.toCharArray();
		for(int i=0;i<str.length();i++)
		{
			for(int j=i+1;j<str.length();j++)
			{
				tempFun(i,j);
			}
		}
	
	}
	static void tempFun(int i,int j)
	{
		//int counter=0;
		String sum=""+arr[i];
		output[counter_temp]=sum;
		counter_temp++;
		for(int counter=j;counter<arr.length;counter++)
		{
			
			//st.add(String.valueOf(arr[i]+arr[j+counter]));
			sum+=String.valueOf(arr[counter]);
			output[counter_temp]=sum;
			counter_temp++;
		}
		
	}
	// recursive function
	static void getAllSubSeq(String str,String temp)
	{
		if(str.length()==0)
		{
			System.out.print("\t"+temp);
			return;
		}
		getAllSubSeq(str.substring(1), temp+str.substring(0,1));
		getAllSubSeq(str.substring(1), temp);
	}
	//aabc
	//[aa, a, ab, bc, b, aab, abc, c, aabc]
	//[aa, bc, a, ab, b, ac, aac, abc, c, aab, aabc]
	public static void main(String[] args) {
		String s="aabc";
/*		getSequence(s);
		for(String st:output)
		{
			System.out.print(st+"\t");
		}
		*/
		//subsequence(s);
		//System.out.println(st.toString());
		//getAllSubSeq("aabc","");
		
		ArrayList<Integer>list=new ArrayList<Integer>();
		for(int i=0;i<1000;i++)
			list.add(i);
		list.remove(300);
	}

}
