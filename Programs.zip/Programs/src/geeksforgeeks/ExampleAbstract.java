/**
 * 
 */
package geeksforgeeks;

/**
 * @author jsaini
 *
 */
abstract class  ExampleAbstract {
	 int current_salary;
	 
	public void updateCurrentSalary(int salary)
	{
		
		current_salary=salary;
	}
	public abstract void getSalary();
	public abstract void updateIncreament();
}
abstract class ExampleAbstract1 extends ExampleAbstract{
	
}
class Subclass extends ExampleAbstract{

	/* (non-Javadoc)
	 * @see geeksforgeeks.ExampleAbstract#getSalary()
	 */
	@Override
	public void getSalary() {
		
		ExampleAbstract obj =new Subclass();
		
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see geeksforgeeks.ExampleAbstract#updateIncreament()
	 */
	@Override
	public void updateIncreament() {
		// TODO Auto-generated method stub
		
	}
	
}
 interface ExampleInterface{
	 int current_salary=500;
	 public abstract void getSalary();
	
	 public static void calculateSalary() {
		 
	 }
}
 
