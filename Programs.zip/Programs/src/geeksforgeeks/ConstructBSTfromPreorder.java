/**
 * 
 */
package geeksforgeeks;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Queue;

/**
 * @author jsaini
 *
 */

public class ConstructBSTfromPreorder {
	Index index=new Index();
	
	BinaryTreeNode constructBinaryTreeUtil(int[] pre, int low, int high, Index preIndex, int size)
	{
		if (preIndex.index >= size || low > high) {
            return null;
        }
		BinaryTreeNode root=new BinaryTreeNode(pre[preIndex.index]);
		preIndex.index=preIndex.index+1;
		
		if(low==high)
			return root;
		int i;
		for(i =low;i<high;++i)
		{
			if(pre[i]>root.data)
				break;
		}
		
		root.left=constructBinaryTreeUtil(pre,preIndex.index,i-1,preIndex,size);
		root.left=constructBinaryTreeUtil(pre,i,high,preIndex,size);
		return root;
	}
	void printInorder(BinaryTreeNode node) {
        if (node == null) {
            return;
        }
        printInorder(node.left);
        System.out.print(node.data + " ");
        printInorder(node.right);
    }
	BinaryTreeNode constructTree(int[] pre,int size)
	{
		return constructBinaryTreeUtil(pre,0,size-1,index,size);
	}
	public static void main(String[] args) {
	
		/*ConstructBSTfromPreorder obj = new ConstructBSTfromPreorder();
		int pre[] = new int[]{10, 5, 1, 7, 40, 50};
		int size = pre.length;
		BinaryTreeNode root=obj.constructTree(pre, size);
		System.out.println("Inorder traversal of the constructed tree is ");
		obj.printInorder(root);*/
		
		
		Hashtable<String, String>ht=new Hashtable<String,String>();
		ht.put("name", "jitendra");
		System.out.println(ht);
		
		HashMap<String,String>map=new HashMap<String,String>();
		map.put("jitendra", null);
		map.put(null, "lj");
		System.out.println(map);
	}

}
class Index{
	int index=0;
}
