/**
 * 
 */
package geeksforgeeks;

/**
 * @author jsaini
 *
 */
public class StringDivisibleByN {
	
	public static int checkDivisible(int[] arr)
	{
		return 0;
	}
	
	public static void main(String[] args) {
		
/*		int arr[]= {1,2,3,4,6};
		checkDivisible(arr);*/
		System.out.println(((int)'5')-48);
		System.out.println(('5'-48) * ('8'-48));
	}

}
