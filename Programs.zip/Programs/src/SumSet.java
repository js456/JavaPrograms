/**
 * 
 */

import java.util.ArrayList;
import java.util.Arrays;
/**
 * @author jsaini
 *
 */


class SumSet {
	
	static void sum_up_nonrecursive(Integer []numbers, int target)
	{
		ArrayList<ArrayList<Integer>>list= new ArrayList<ArrayList<Integer>>();
		for(int i=0;i<numbers.length;i++)
		{
			ArrayList<Integer>temp_list= new ArrayList<Integer>();
			if(numbers[i]>target)
				continue;
			else if(numbers[i]==target)
			{
				temp_list.add(numbers[i]);
				temp_list.clear();
				list.add(temp_list);
				continue;
			}
			
			temp_list.add(numbers[i]);
			for(int j=i+1;j<numbers.length;j++)
			{
				int total=0;
				for (int x: temp_list) total += x;
				if(total+numbers[j]>target)
					continue;
				else if(total+numbers[j]==target)
				{
					temp_list.add(numbers[j]);
					list.add(temp_list);
					temp_list.clear();
					continue;
				}
				else if(total+numbers[j] <target)
				{
					temp_list.add(numbers[j]);
					continue;
				}
			}
		}
		System.out.println(list.toString());
	}
    static void sum_up_recursive(ArrayList<Integer> numbers, int target, ArrayList<Integer> partial) {
       int s = 0;
       for (int x: partial) s += x;
       if (s == target)
            System.out.println("sum("+Arrays.toString(partial.toArray())+")="+target);
       if (s >= target)
            return;
       for(int i=0;i<numbers.size();i++) {
             ArrayList<Integer> remaining = new ArrayList<Integer>();
             int n = numbers.get(i);
             for (int j=i+1; j<numbers.size();j++) remaining.add(numbers.get(j));
             ArrayList<Integer> partial_rec = new ArrayList<Integer>(partial);
             partial_rec.add(n);
             sum_up_recursive(remaining,target,partial_rec);
       }
    }
    static void sum_up(ArrayList<Integer> numbers, int target) {
        sum_up_recursive(numbers,target,new ArrayList<Integer>());
    }
    public static void main(String args[]) {
        Integer[] numbers = {3,9,8,4,5,7,10};
        int target = 15;
        sum_up(new ArrayList<Integer>(Arrays.asList(numbers)),  target);
      //  sum_up_nonrecursive(numbers,target);
    }
}