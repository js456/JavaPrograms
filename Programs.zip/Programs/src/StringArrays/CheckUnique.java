/**
 * 
 */
package StringArrays;

/**
 * @author jsaini
 *
 */
public class CheckUnique {
	public static boolean isUnique(String str) {
		int checker =0;
		for(int i=0;i<str.length();i++) {
			int val= str.charAt(i) -'a';
			if((checker & (1<<val))>0)return false;
			checker |=(1<<val);
		}
		return true;
	}
	public static void removeDuplicates(String str)
	{
		char []arr= str.toCharArray();
		boolean []asciArr= new boolean[256];
		asciArr[arr[0]]=true;
		int tail=1;
		for(int i=1;i<arr.length;++i)
		{
			if(!asciArr[arr[i]])
			{
				arr[tail]=arr[i];
				++tail;
				asciArr[arr[i]]= true;
			}
		}
		arr[tail]=0;
		System.out.println("Duplicate String :"+str);
		for(char ch:arr) {
			System.out.print(ch);
		}
	
	}
	public static void rotate(int[][] matrix, int n) {
		for (int layer = 0; layer < n / 2; ++layer) {
			int first = layer;
			int last = n - 1 - layer;
			for(int i = first; i < last; ++i) {
				int offset = i - first;
				int top = matrix[first][i]; // save top
				// left -> top
				matrix[first][i] = matrix[last-offset][first];
		
				 // bottom -> left
				 matrix[last-offset][first] = matrix[last][last - offset];
		
				 // right -> bottom
				 matrix[last][last - offset] = matrix[i][last];
		
				 // top -> right
				 matrix[i][last] = top; // right <- saved top
			 }
		 }
		 }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*System.out.println((int)'a');
		System.out.println((int)'z');
		System.out.println((int)'A');
		System.out.println((int)'Z');*/
		/*System.out.println(1<<9);
		System.out.println(4>>1);*/
		removeDuplicates("geeksforgeeks");
	}
}
