/**
 * 
 */
package StringArrays;

/**
 * @author jsaini
 *
 */
public class StockProfit {

	public static void printMaxProfit(int arr[]){
        int a = 0,b =1;
        for(int i=2;i<arr.length;i++)
        {
            if(arr[i]<arr[a])
            	a=i;
            else if(arr[i]<arr[b])
            	b=i;
        }
        //a>b?
        System.out.println("first element : "+arr[a]+" and second element is : "+arr[b]+" ");
    }
	
	public static void main(String[] args) {
		int arr[]= {23,13,25,29,33,19,34,45,65,67};
		printMaxProfit(arr);
	}
}
