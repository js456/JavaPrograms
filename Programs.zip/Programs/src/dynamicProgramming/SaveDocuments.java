/**
 * 
 */
package dynamicProgramming;

import java.util.Arrays;

/**
 * @author jsaini
 *
 */
public class SaveDocuments {

	public static int getMinSteps(int noOfBlocks, int noOfSteps, String inputArr[]) {
		
		char blocks[][]= new char[noOfBlocks][noOfBlocks];
		char tempArr[][]= new char[noOfBlocks][noOfBlocks];
		for(int i=0;i<noOfBlocks;i++)
		{
			for(int j=0;j<noOfBlocks;j++)
			{
				blocks[i][j]=inputArr[i].charAt(j);
				tempArr[i][j]=inputArr[i].charAt(j);
			}
		}
		print2DArr(blocks);
		System.out.println("AFTER INCREASE COMMANDOS");
		increaseCommandos(blocks,tempArr);
		print2DArr(blocks);
		return 0;
	}
	public static void print2DArr(char [][]arr)
	{
		for(char []tempArr:arr)
		{
			System.out.println(Arrays.toString(tempArr));
		}
	}
	public static void increaseCommandos(char [][]arr,char [][]tempArr)
	{
		for(int i=0;i<tempArr.length;i++)
		{
			for(int j=0;j<tempArr.length;j++)
			{
				if(tempArr[i][j]=='T')
				{
					if(i-1>=0 && j >=0)
						arr[i-1][j]='T';
					if(j-1>=0 && i >=0)
						arr[i][j-1]='T';
					if(i+1 <= tempArr.length-1 && j >=0)
						arr[i+1][j]='T';
					if(j+1<=tempArr.length-1 && i >=0)
						arr[i][j+1]='T';
				}
			}
		}
	}
	public static void main(String[] args) {
		
		int noOfBlocks=5;
		int noOfSteps=1;
		System.out.println(0/3);
		String inputArr[]= {"NOOOS","OOOOO","OOOOO","OOOOO","OOOOT"};
		getMinSteps(noOfBlocks, noOfSteps, inputArr);
	}
}
