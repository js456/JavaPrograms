/**
 * 
 */
package multithreading;

import java.util.concurrent.Callable;

/**
 * @author jsaini
 *
 */
public class CllableVsRunnable implements Runnable {

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
	
	}
}

class TestCallable implements Callable<String>{

	/* (non-Javadoc)
	 * @see java.util.concurrent.Callable#call()
	 */
	@Override
	public String call() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
}