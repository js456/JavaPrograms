/**
 * 
 */
package multithreading;

import java.util.concurrent.CountDownLatch;

/**
 * @author jsaini
 *
 */
public class ThreadJoin implements Runnable{

	public static void main(String[] args) {
		
		CountDownLatch latch ;
		Thread t1 = new Thread(new ThreadJoin(),"Thread 1");
		Thread t2 = new Thread(new ThreadJoin(),"Thread 2");
		Thread t3 = new Thread(new ThreadJoin(),"Thread 3");
		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t3.start();
	}

	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Entring -->"+Thread.currentThread().getName());
		for(int i=1;i<100;i++) {
			try {
				System.out.println("Executing -->"+Thread.currentThread().getName()+" value is: "+i);
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
