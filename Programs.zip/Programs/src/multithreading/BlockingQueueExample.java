/**
 * 
 */
package multithreading;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 * @author jsaini
 *
 */
public class BlockingQueueExample {
	
	public static void main(String[] args) throws InterruptedException, CloneNotSupportedException {
		BlockingQueue queue = new ArrayBlockingQueue<>(1024);
		Producer producer = new Producer(queue);
		Consumer consumer = new Consumer(queue);
		new Thread(producer).start();
		new Thread(consumer).start();
		Thread.sleep(4000);
		Producer obj = (Producer)producer.clone();
	}

}
class Producer implements Runnable{

	protected BlockingQueue queue = null;
	/**
	 * 
	 */
	public Producer(BlockingQueue queue){
		this.queue = queue;
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			queue.put("1");
			Thread.sleep(3000);
			queue.put("2");
			Thread.sleep(1000);
			queue.put("3");
		}
		catch (InterruptedException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
}
class Consumer implements Runnable{
	
	protected BlockingQueue queue;
	/**
	 * 
	 */
	public Consumer(BlockingQueue queue) {
		this.queue= queue;
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		try {
			System.out.println(queue.take());
			System.out.println(queue.take());
			System.out.println(queue.take());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
}