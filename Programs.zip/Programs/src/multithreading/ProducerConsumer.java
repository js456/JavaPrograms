/**
 * 
 */
package multithreading;

import java.util.concurrent.ExecutorService;

/**
 * @author jsaini
 *
 */
public class ProducerConsumer {

	ExecutorService obj;
}
