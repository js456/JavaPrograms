/**
 * 
 */
package multithreading;

/**
 * @author jsaini
 *
 */
public class CreateDeadlock {

	public static void main(String[] args) {
		
		Thread t1=new Thread(new Runnable()
		{

			@Override
			public void run() {
				synchronized (String.class) {
					try {
						Thread.sleep(100);
						synchronized (Object.class) {
							
						}
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				// TODO Auto-generated method stub
				
			}
	
		});
		Thread t2=new Thread(new Runnable()
		{

			@Override
			public void run() {
				synchronized (Object.class) {
					try {
						Thread.sleep(100);
						synchronized (String.class) {
							
						}
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				// TODO Auto-generated method stub
				
			}
	
		});
		t1.start();
		t2.start();
	}
}
