/**
 * 
 */
package multithreading;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jsaini
 *
 */
public class ConcurrentHashMapTest {

	public static void main(String[] args) {
		
		Map<String,Integer> hashMap = new HashMap<String,Integer>();
		Map<String,Integer>map= new ConcurrentHashMap<String,Integer>();
		Helper1 helper1 = new Helper1(map);
		Helper2 helper2 = new Helper2(map);
		Helper3 helper3 = new Helper3(map);
		Helper4 helper4 = new Helper4(map);
		
		for(Map.Entry<String, Integer> e:map.entrySet())
		{
			System.out.println(e.getKey()+" : "+e.getValue());
		}
		/*Thread t1 = new Thread(helper1);
		Thread t2 = new Thread(helper2);
		Thread t3 = new Thread(helper3);
		Thread t4 = new Thread(helper4);
		t1.start();
		t2.start();
		t3.start();
		t4.start();*/
	}
}


