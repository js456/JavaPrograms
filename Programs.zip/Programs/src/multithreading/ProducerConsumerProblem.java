/**
 * 
 */
package multithreading;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author jsaini
 *
 */
public class ProducerConsumerProblem {
	public static void main(String[] args) {
		BlockingQueue queue = new LinkedBlockingQueue(10);
		
		Producer1 producer = new Producer1(queue);
		ObeserverConsumer obConsumer = new ObeserverConsumer(queue, producer);
		RemoveConsumer1 rmConsumer = new RemoveConsumer1(queue, producer);
		
		Thread producerThread = new Thread(producer);
		Thread obConsumerThread = new Thread(obConsumer);
		Thread rmConsumerThread = new Thread(rmConsumer);
		
		producerThread.start();
		obConsumerThread.start();
		rmConsumerThread.start();
		
	}

}
class Producer1 implements Runnable{
	private BlockingQueue queue ;
	private boolean running;
	/**
	 * 
	 */
	public Producer1(BlockingQueue queue) {
		this.queue = queue;
		running = true;
		// TODO Auto-generated constructor stub
	}
	public boolean isRunning()
	{
		return running;
	}
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i =0;i<15;i++)
		{
			try {
				queue.put("String "+i);
				System.out.println("P\tAdding element: " + "String "+i);
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		System.out.println("Producer completed");
		running=false;
	}
	
}
class RemoveConsumer1 implements Runnable{
	private BlockingQueue queue ;
	private Producer1 producer;
	/**
	 * 
	 */
	public RemoveConsumer1(BlockingQueue queue,Producer1 producer) {
		this.queue = queue;
		this.producer = producer;
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(producer.isRunning())
		{
			try {
				System.out.println("RC \t Removing element: "+queue.take());
				Thread.sleep(800);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("RC Completed");
	}
	
}
class ObeserverConsumer implements Runnable{
	private BlockingQueue queue ;
	private Producer1 producer;
	/**
	 * 
	 */
	public ObeserverConsumer(BlockingQueue queue,Producer1 producer) {
		this.queue = queue;
		this.producer = producer;
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(producer.isRunning())
		{
			try {
				System.out.println("RC \t Elements in queue: "+queue);
				Thread.sleep(800);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("RC Completed");
	}
	
}