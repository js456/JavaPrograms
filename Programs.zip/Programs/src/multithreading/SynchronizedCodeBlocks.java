/**
 * 
 */
package multithreading;

import java.util.ArrayList;
import java.util.Random;

/**
 * @author jsaini
 *
 */
public class SynchronizedCodeBlocks {
	
	ArrayList <Integer>list1=new ArrayList<Integer>();
	ArrayList <Integer>list2=new ArrayList<Integer>();
	Random random = new Random();
	Object obj1 = new Object();
	Object obj2 = new Object();
	public void stageOne()
	{
		synchronized (obj1) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			list1.add(100);
			
		}
	
	}
	public void stageTwo()
	{
		synchronized (obj2) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				list2.add(100);
		}
		
	}
	public void process()
	{
		for(int i=0;i<1000;i++)
		{
			stageOne();
			stageTwo();
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Starting");
		SynchronizedCodeBlocks obj = new SynchronizedCodeBlocks();
		Thread t1= new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				obj.process();
			}
			
		});
		Thread t2= new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				obj.process();
			}
			
		});
		long start = System.currentTimeMillis();
		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long end = System.currentTimeMillis();
		
		System.out.println("time take to execution :     "+(end - start));
		System.out.println(" List 1 size :"+obj.list1.size()+" List 2 size : "+obj.list2.size());
		
		
	}


}
