/**
 * 
 */
package multithreading;

import java.util.Map;

/**
 * @author jsaini
 *
 */
public class Helper4 implements Runnable{

	private Map<String,Integer>map;
	/**
	 * 
	 */
	public Helper4(Map<String,Integer> map) {
		this.map = map;
		new Thread(this,"Helper4").start();
	}
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		map.put("four", 4);
		try {
			Thread.sleep(100);
			System.out.println(" Map Helper 4 Sleeping");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
}

	
