/**
 * 
 */
package multithreading;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * @author jsaini
 *
 */
public class ScheduledExecutorServiceExample {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ScheduledExecutorService executer = Executors.newScheduledThreadPool(5);
		ScheduledFuture scheduledFuture = executer.schedule(new Callable<Object>() {
			@Override
			public Object call() throws Exception {
				// TODO Auto-generated method stub
				System.out.println("Executed");
				return "Called";
			}
		}, 5, TimeUnit.SECONDS);
		ScheduledFuture scheduledFuture1 = executer.schedule(new Callable<Object>() {
			@Override
			public Object call() throws Exception {
				// TODO Auto-generated method stub
				System.out.println("Executed");
				return "Called";
			}
		}, 5, TimeUnit.SECONDS);
		System.out.println(scheduledFuture.isDone());	
		System.out.println("result of thread is: "+scheduledFuture.get());
		System.out.println(Thread.activeCount());
		executer.shutdown();
	}
}
