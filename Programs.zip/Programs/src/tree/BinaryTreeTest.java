/**
 * 
 */
package tree;

import org.junit.jupiter.api.Test;

/**
 * @author jsaini
 *
 */
public class BinaryTreeTest {

	@Test
	public void BinaryTreeAddTest()
	{
		BinaryTree tree= new BinaryTree(55);
		tree.add(25);
		tree.add(35);
		tree.add(15);
		tree.add(65);
		tree.add(62);
		tree.add(100);
		tree.add(5);
		
		tree.delete(55);
		tree.traverse();
	}
}
