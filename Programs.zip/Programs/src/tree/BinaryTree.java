/**
 * 
 */
package tree;

/**
 * @author jsaini
 *
 */
public class BinaryTree {
	
	private BinaryTreeNode root;
	BinaryTree(int data)
	{
		root = new BinaryTreeNode(data);
	}
	public void add(int element)
	{
		addHelper(new BinaryTreeNode(element),root);
	}
	public void traverse() {
		inorderTraverse(root);
	}
	public void delete(int element)
	{
		// case 1 where node does not have child
		BinaryTreeNode nodeToDelete=find(element);
		if(nodeToDelete.getLeftChild() == null && nodeToDelete.getRightChild() == null)
		{
			BinaryTreeNode parent =nodeToDelete.getParent();
			if(nodeToDelete == parent.getLeftChild())
				parent.setLeftChild(null);
			if(nodeToDelete == parent.getRightChild())
				parent.setRightChild(null);
		}
		if(nodeToDelete.getLeftChild() != null && nodeToDelete.getRightChild() != null)
		{
			deleteCase3(nodeToDelete);
		}
		else {
			deleteCase2(nodeToDelete);
		}
		// case 2 where node has one right or left child
		
		// case 3 if it has both right and left child
	}
	/**
	 * @param nodeToDelete
	 */
	private void deleteCase2(BinaryTreeNode nodeToDelete) {
		// TODO Auto-generated method stub
		if(nodeToDelete.getLeftChild() != null && nodeToDelete.getRightChild() == null)
		{
			BinaryTreeNode parent =nodeToDelete.getParent();
			parent.setLeftChild(nodeToDelete.getLeftChild());
		}
		// if it has one right child
		if(nodeToDelete.getLeftChild() == null && nodeToDelete.getRightChild() != null)
		{
			BinaryTreeNode parent =nodeToDelete.getParent();
			parent.setRightChild(nodeToDelete.getRightChild());
		}
	}
	/**
	 * @param nodeToDelete
	 */
	private void deleteCase3(BinaryTreeNode nodeToDelete) {
		// TODO Auto-generated method stub
		BinaryTreeNode minNode = getLeftMinNode(nodeToDelete.getRightChild());
		deleteCase2(minNode);
		minNode.setLeftChild(nodeToDelete.getLeftChild());
		minNode.setRightChild(nodeToDelete.getRightChild());
		minNode.setParent(nodeToDelete.getParent());
		if(nodeToDelete.getParent() == null)
			root= minNode;
		else if(nodeToDelete.getParent().getLeftChild() == nodeToDelete) {
			nodeToDelete.getParent().setLeftChild(minNode);
		}
		else if(nodeToDelete.getParent().getRightChild() == nodeToDelete)
		{
			nodeToDelete.getParent().setRightChild(minNode);
		}
	}
	/**
	 * @param rightChild
	 * @return
	 */
	private BinaryTreeNode getLeftMinNode(BinaryTreeNode rightChild) {
		if(rightChild.getLeftChild() == null)
			return rightChild;
		else
			return getLeftMinNode(rightChild.getLeftChild());
	}
	public BinaryTreeNode find(int value) {
		return findNode(root, value);
	}
	/**
	 * @param root2
	 * @param value
	 * @return
	 */ 
	private BinaryTreeNode findNode(BinaryTreeNode root2, int value) {
		// TODO Auto-generated method stub
		if(root2.getData() == value)
			return root2;
		else if(value < root2.getData()) {
			return findNode(root2.getLeftChild(), value);
		}
		else
		{
			return findNode(root2.getRightChild(), value);
		}
	}
	/**
	 * @param root2
	 */
	private void inorderTraverse(BinaryTreeNode root) {
		// TODO Auto-generated method stub
		if(root == null)
			return;
		inorderTraverse(root.getLeftChild());
		System.out.println(root.getData());
		inorderTraverse(root.getRightChild());
	}
	private void addHelper(BinaryTreeNode nodeToAdd,BinaryTreeNode node)
	{
		if(nodeToAdd.getData()<node.getData())
		{
			if(node.getLeftChild()== null) {
				node.setLeftChild(nodeToAdd);
				nodeToAdd.setParent(node);
			}
			else {
				addHelper(nodeToAdd,node.getLeftChild());
			}
		}
		if(nodeToAdd.getData()>node.getData())
		{
			if(node.getRightChild()== null) {
				node.setRightChild(nodeToAdd);
				nodeToAdd.setParent(node);
			}
			else
				addHelper(nodeToAdd,node.getRightChild());
		}
	}
}
