/**
 * 
 */

/**
 * @author jsaini
 *
 */
public class TestOverloading {
	
	public Integer getNumber(Integer x, Integer y)
	{
		return x+y;
	}
	public String getNumber(String x, String y)
	{
		return x+y;
	}
	public static void swap(Demo arg1, Demo arg2)
	{
		arg1.x=100;arg1.y=100;
		Demo temp =arg2;
		arg2 = temp;
		arg1 = temp;
	}
	public static void main(String[] args) {
		TestOverloading obj = new TestOverloading();
		//System.out.println(getNumber(null,null));
		Demo d1 = new Demo(0,0);
		Demo d2 = new Demo(0,0);
		
	}

}

class Demo{
	int x;
	int y;
	Demo(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
	
}