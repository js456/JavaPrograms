/**
 * 
 */
package cutsomUtils;

/**
 * @author jsaini
 *
 */
public class Address {
	
	private String address;
	/**
	 * 
	 */
	public Address(String address) {
		this.address=address;
		// TODO Auto-generated constructor stub
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	

}
