/**
 * 
 */
package cutsomUtils;

import java.util.Arrays;

/**
 * @author jsaini
 *
 */
public class CustomArrayList <T> {
	int intialCapicity=10;
	private int size=0;
	private Object elements[];
	CustomArrayList(T t)
	{
		elements = new Object[intialCapicity];
	}
	public void add(T t)
	{
		if(size == elements.length) {
			ensureCapa();
		}
		elements[size++]=t;
	}
	private void ensureCapa()
	{
		int newSize= elements.length*2;
		elements= Arrays.copyOf(elements, newSize);
	}
	
}
