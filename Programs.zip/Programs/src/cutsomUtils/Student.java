/**
 * 
 */
package cutsomUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeMap;

/**
 * @author jsaini
 *
 */
public final class Student extends ArrayList<Student>{

	
	private int  age=24;
	private Address address;
	private ArrayList<String>hobbies;
	/**
	 * 
	 */
	public Student( int age, Address address) {
		this.age= age;
		try {
			this.address= (Address)address.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}
	
	
	public int getAge() {
		return age;
	}

	public Address getAddress() {
		return address;
	}

	public static void print(int i)
	{
		i =2;
	}
	public static void print1(int i)
	{
		System.out.println(i);
		print1(--i);
	}
	public static void main(String[] args) {
		print1(10);
		Address add = new Address("Marathalli");
		HashSet set;
		TreeMap map;
		Student st = new Student(24, add);
		System.out.println(st.hashCode());
		System.out.println(st.getAge());
		System.out.println(st.getAddress().getAddress());
		add.setAddress("Whitefield");
		System.out.println(st.getAddress().getAddress());
		
	}
}

